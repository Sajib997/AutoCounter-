# Auto Counter (Android)

A small native Android app that tracks a live net value.

## Features
- Set an initial value (for example, 50000).
- Apply signed one-time adjustments (for example, +5000 or -7000).
- Start one or more signed continuous rates (for example, +12/sec or -3/sec).
- Displays the value to two decimal places and refreshes while the app is open.
- Persists all entries and timestamps locally. When reopened, it calculates the correct value using elapsed time, so rates continue while the app is closed.
- Green when the current value is at or above the month's baseline; red when below.
- The initial value is the baseline for the month in which the counter is first set up. At the start of each later calendar month, the app snapshots the calculated value as the new baseline.
- Stop all running rates without losing the amount already accrued.

## Build the APK
1. Install Android Studio (Hedgehog or newer) with Android SDK Platform 35.
2. Open this `AutoCounter` folder in Android Studio.
3. Allow Gradle sync to finish (requires internet the first time to download Android Gradle Plugin).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 6.0 (API 23).

## Calculation model
Current value = initial value + all one-time adjustments whose timestamps have passed + each rate multiplied by its elapsed seconds. A rate is stopped at the timestamp when **Stop all running rates** is pressed. All times are stored as device timestamps and calculations use actual elapsed time.
