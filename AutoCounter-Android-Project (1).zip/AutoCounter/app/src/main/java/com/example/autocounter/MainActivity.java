package com.example.autocounter;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;

public class MainActivity extends Activity {
    private static class Entry { double amount; long time; Entry(double a,long t){amount=a;time=t;} }
    private static class Rate { double perSecond; long start; long end; Rate(double r,long s,long e){perSecond=r;start=s;end=e;} }
    private SharedPreferences prefs;
    private final ArrayList<Entry> entries = new ArrayList<>();
    private final ArrayList<Rate> rates = new ArrayList<>();
    private double initialValue, monthBaseline;
    private long createdAt;
    private String baselineMonth="";
    private TextView valueView, baselineView, ratesView, statusView;
    private EditText adjustmentInput, rateInput;
    private final Handler handler = new Handler();
    private final DecimalFormat fmt = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US));

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("counter",MODE_PRIVATE);
        if (!prefs.getBoolean("configured",false)) showSetup(); else { load(); buildMain(); refresh(); }
    }

    private void showSetup(){
        LinearLayout root=page();
        TextView title=text("AUTO COUNTER",26,true); root.addView(title);
        TextView hint=text("Enter your starting net value. The app will remember it and calculate continuously.",15,false); root.addView(hint);
        EditText start=edit("Initial value (e.g. 50000)"); root.addView(start);
        Button go=button("Start counter"); root.addView(go);
        go.setOnClickListener(v->{ Double n=parse(start.getText().toString()); if(n==null){start.setError("Enter a valid number");return;} initialValue=n;createdAt=System.currentTimeMillis();monthBaseline=n;baselineMonth=monthKey(createdAt);save();buildMain();refresh(); });
        setContentView(root);
    }

    private void buildMain(){
        ScrollView scroll=new ScrollView(this); LinearLayout root=page(); scroll.addView(root);
        root.addView(text("AUTO COUNTER",22,true));
        root.addView(text("Live net value",14,false));
        valueView=text("0.00",40,true); valueView.setGravity(Gravity.CENTER); root.addView(valueView);
        baselineView=text("Monthly starting value: —",13,false); root.addView(baselineView);
        statusView=text("",13,false); root.addView(statusView);
        root.addView(separator());
        root.addView(text("Add or remove a one-time amount",17,true));
        adjustmentInput=edit("Example: +5000 or -7000"); root.addView(adjustmentInput);
        Button add=button("Apply adjustment"); root.addView(add);
        add.setOnClickListener(v->{Double n=parse(adjustmentInput.getText().toString());if(n==null||n==0){adjustmentInput.setError("Enter a non-zero amount, e.g. 5000 or -7000");return;}entries.add(new Entry(n,System.currentTimeMillis()));adjustmentInput.setText("");hideKeyboard();save();refresh();});
        root.addView(separator());
        root.addView(text("Add a time-based rate",17,true));
        root.addView(text("Positive increases the value; negative decreases it. Example: 12 or -3 per second.",13,false));
        rateInput=edit("Amount per second (e.g. 12 or -3)"); root.addView(rateInput);
        Button startRate=button("Start rate"); root.addView(startRate);
        startRate.setOnClickListener(v->{Double n=parse(rateInput.getText().toString());if(n==null||n==0){rateInput.setError("Enter a non-zero rate");return;}rates.add(new Rate(n,System.currentTimeMillis(),0));rateInput.setText("");hideKeyboard();save();refresh();});
        root.addView(separator());
        root.addView(text("Running rates",17,true)); ratesView=text("No active rates",14,false); root.addView(ratesView);
        Button stopAll=button("Stop all running rates"); root.addView(stopAll);
        stopAll.setOnClickListener(v->{long now=System.currentTimeMillis();for(Rate r:rates)if(r.end==0)r.end=now;save();refresh();});
        Button reset=button("Reset counter / enter new starting value"); root.addView(reset);
        reset.setOnClickListener(v->{new android.app.AlertDialog.Builder(this).setTitle("Reset counter?").setMessage("This clears the current history and asks for a new initial value.").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{prefs.edit().clear().apply();entries.clear();rates.clear();showSetup();}).show();});
        root.addView(text("The counter keeps accruing while the app is closed. It recalculates from saved timestamps when reopened.",12,false));
        setContentView(scroll);
    }

    private void refresh(){
        long now=System.currentTimeMillis();
        String mk=monthKey(now);
        if(!mk.equals(baselineMonth)){monthBaseline=valueAt(monthStart(now));baselineMonth=mk;save();}
        double value=valueAt(now);
        valueView.setText(fmt.format(value));
        int c=value>=monthBaseline?Color.rgb(20,145,75):Color.rgb(205,45,55);
        valueView.setTextColor(c);
        baselineView.setText("Monthly starting value: "+fmt.format(monthBaseline));
        statusView.setText(value>=monthBaseline?"Above this month's starting value":"Below this month's starting value");
        StringBuilder b=new StringBuilder(); int count=0;
        for(int i=0;i<rates.size();i++){Rate r=rates.get(i);if(r.end==0){if(count++>0)b.append("\n");b.append((r.perSecond>0?"+":"")).append(fmt.format(r.perSecond)).append(" / sec");}}
        ratesView.setText(count==0?"No active rates":b.toString());
    }

    private double valueAt(long t){
        double v=initialValue;
        for(Entry e:entries)if(e.time<=t)v+=e.amount;
        for(Rate r:rates){long stop=r.end==0?t:Math.min(t,r.end);long from=Math.max(r.start,createdAt);if(stop>from)v+=r.perSecond*((stop-from)/1000.0);}
        return v;
    }
    private long monthStart(long t){Calendar c=Calendar.getInstance();c.setTimeInMillis(t);c.set(Calendar.DAY_OF_MONTH,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();}
    private String monthKey(long t){Calendar c=Calendar.getInstance();c.setTimeInMillis(t);return c.get(Calendar.YEAR)+"-"+(c.get(Calendar.MONTH)+1);}

    private void save(){try{JSONObject o=new JSONObject();o.put("configured",true);o.put("initial",initialValue);o.put("created",createdAt);o.put("baseline",monthBaseline);o.put("baselineMonth",baselineMonth);JSONArray es=new JSONArray();for(Entry e:entries){JSONObject x=new JSONObject();x.put("a",e.amount);x.put("t",e.time);es.put(x);}o.put("entries",es);JSONArray rs=new JSONArray();for(Rate r:rates){JSONObject x=new JSONObject();x.put("r",r.perSecond);x.put("s",r.start);x.put("e",r.end);rs.put(x);}o.put("rates",rs);prefs.edit().putString("data",o.toString()).putBoolean("configured",true).apply();}catch(Exception ignored){}}
    private void load(){try{JSONObject o=new JSONObject(prefs.getString("data","{}"));initialValue=o.optDouble("initial",0);createdAt=o.optLong("created",System.currentTimeMillis());monthBaseline=o.optDouble("baseline",initialValue);baselineMonth=o.optString("baselineMonth",monthKey(createdAt));JSONArray es=o.optJSONArray("entries");if(es!=null)for(int i=0;i<es.length();i++){JSONObject x=es.getJSONObject(i);entries.add(new Entry(x.getDouble("a"),x.getLong("t")));}JSONArray rs=o.optJSONArray("rates");if(rs!=null)for(int i=0;i<rs.length();i++){JSONObject x=rs.getJSONObject(i);rates.add(new Rate(x.getDouble("r"),x.getLong("s"),x.getLong("e")));}}catch(Exception e){initialValue=0;createdAt=System.currentTimeMillis();monthBaseline=0;baselineMonth=monthKey(createdAt);}}

    private LinearLayout page(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(22,24,22,28);l.setBackgroundColor(Color.rgb(250,250,252));return l;}
    private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(35,40,48));t.setPadding(0,8,0,8);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(8194|4096);e.setTextSize(16);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private View separator(){View v=new View(this);v.setBackgroundColor(Color.LTGRAY);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,1);p.setMargins(0,16,0,16);v.setLayoutParams(p);return v;}
    private Double parse(String s){try{return Double.parseDouble(s.trim().replace(",",""));}catch(Exception e){return null;}}
    private void hideKeyboard(){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(),0);}catch(Exception ignored){}}
    @Override protected void onResume(){super.onResume();handler.post(tick);}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(tick);save();}
    private final Runnable tick=new Runnable(){public void run(){if(valueView!=null){refresh();handler.postDelayed(this,100);}}};
}
